package com.jxz.panel;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.widget.TextView;

public class FloatingService extends Service {
    private WindowManager wm;
    private TextView bubble;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setText("JXZ");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(14);
        bubble.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundColor(Color.rgb(190, 0, 35));
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        params = new WindowManager.LayoutParams(130, 130, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 20; params.y = 260;
        bubble.setOnTouchListener(new android.view.View.OnTouchListener() {
            private int startX, startY; private float downX, downY; private boolean moved;
            @Override public boolean onTouch(android.view.View v, MotionEvent e) {
                switch(e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX=params.x; startY=params.y; downX=e.getRawX(); downY=e.getRawY(); moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=(int)(e.getRawX()-downX), dy=(int)(e.getRawY()-downY);
                        if(Math.abs(dx)>6 || Math.abs(dy)>6) moved=true;
                        params.x=startX+dx; params.y=startY+dy;
                        wm.updateViewLayout(bubble, params); return true;
                    case MotionEvent.ACTION_UP:
                        if(!moved) {
                            Intent i = new Intent(FloatingService.this, MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(i);
                        }
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, params);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() { if(wm!=null && bubble!=null) try{wm.removeView(bubble);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
