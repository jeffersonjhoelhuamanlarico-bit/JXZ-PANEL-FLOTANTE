package com.jxz.panel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9,7,11));
        getWindow().setNavigationBarColor(Color.rgb(9,7,11));
        if (Settings.canDrawOverlays(this)) { showPanel(); return; }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(28, 28, 28, 28);
        layout.setBackgroundColor(Color.rgb(9,7,11));
        TextView title = new TextView(this);
        title.setText("JXZ PANEL\n\nPara activar el botón flotante, permite que esta app se muestre sobre otras aplicaciones.\n\nEl panel solo abre los ajustes; no modifica Free Fire.");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));
        Button allow = new Button(this);
        allow.setText("ACTIVAR BOTÓN FLOTANTE");
        layout.addView(allow, new LinearLayout.LayoutParams(-1, -2));
        allow.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        setContentView(layout);
    }

    @Override protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) showPanel();
    }

    private void showPanel() {
        startService(new Intent(this, FloatingService.class));
        WebView web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
}
